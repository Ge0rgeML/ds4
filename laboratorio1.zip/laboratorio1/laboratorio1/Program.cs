﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Hola mundo!!!");
    }
}